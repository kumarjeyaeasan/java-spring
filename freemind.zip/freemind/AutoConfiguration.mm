<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1639043805058" ID="ID_1547367550" MODIFIED="1639043835610" STYLE="bubble" TEXT="AutoConfiguration">
<node CREATED="1639043811731" HGAP="8" ID="ID_1393926775" MODIFIED="1639043877310" POSITION="right" TEXT="@SpringBootApplication" VSHIFT="-47">
<node CREATED="1639043811733" MODIFIED="1639043822088" TEXT="Indicates its a spring boot application"/>
<node CREATED="1639043811735" MODIFIED="1639043822088" TEXT="It Enables AutoConfiguration"/>
<node CREATED="1639043811736" MODIFIED="1639043822088" TEXT="It Enables Component Scan"/>
</node>
<node CREATED="1639043811738" HGAP="15" ID="ID_344501432" MODIFIED="1639043874565" POSITION="right" TEXT="SpringBoot Looks at" VSHIFT="50">
<node CREATED="1639043811740" MODIFIED="1639043822089" TEXT="Frameworks Available on the CLASSPATH"/>
<node CREATED="1639043811742" ID="ID_901589696" MODIFIED="1639043822089" TEXT="Existing configurations for the application">
<node CREATED="1639043811744" ID="ID_27087755" MODIFIED="1639043897920" TEXT="Based on the above two, Spring boot provides the basic configuration needed for the application. This is called Auto Configuration"/>
</node>
</node>
</node>
</map>
