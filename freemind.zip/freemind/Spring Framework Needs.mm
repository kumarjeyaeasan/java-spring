<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1638766642982" ID="ID_531106416" MODIFIED="1639142326972" STYLE="bubble" TEXT="Spring Framework Needs">
<node CREATED="1638767727858" ID="ID_1741060278" LINK="mailto:(@Component)" MODIFIED="1638767822323" POSITION="right" TEXT="What are beans (@Component)"/>
<node CREATED="1638767727864" ID="ID_755971799" LINK="mailto:(@Autowired)" MODIFIED="1638767763706" POSITION="right" TEXT="What are dependencies (@Autowired)"/>
<node CREATED="1638767727865" ID="ID_1173655420" MODIFIED="1638767824524" POSITION="right" TEXT="Where to Find Beans">
<node CREATED="1638767727867" HGAP="15" ID="ID_1618056144" MODIFIED="1638767845938" TEXT="@SpringBootApplication Class" VSHIFT="85">
<node CREATED="1638767727869" ID="ID_807012844" MODIFIED="1638767854253" TEXT="if bean class is same package as no need mention">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1638767727870" ID="ID_1421483780" MODIFIED="1638767763707" TEXT="This class contains ApplicationContext"/>
<node CREATED="1638767727874" ID="ID_1221135602" MODIFIED="1638767763707" TEXT="This Class have main() Method"/>
</node>
</node>
</node>
</map>
