<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1638962607175" ID="ID_19016422" MODIFIED="1639142024682" STYLE="bubble" TEXT="Annotations">
<node CREATED="1638968232615" HGAP="85" ID="ID_1246456884" MODIFIED="1639142159210" POSITION="left" TEXT="JUnit" VSHIFT="-208">
<node CREATED="1638968232617" ID="ID_770410320" MODIFIED="1638968260470" TEXT="Order of Execution of Tests not guaranteed" VSHIFT="-18"/>
<node CREATED="1638968232619" ID="ID_332697259" MODIFIED="1638968267629" TEXT="Assert Method" VSHIFT="-20">
<node CREATED="1638968232620" MODIFIED="1638968232620" TEXT="assertEquals()"/>
<node CREATED="1638968232622" MODIFIED="1638968232622" TEXT="assertTrue()"/>
<node CREATED="1638968232624" MODIFIED="1638968232624" TEXT="assertFalse()"/>
<node CREATED="1638968232625" MODIFIED="1638968232625" TEXT="assertNotNull()"/>
<node CREATED="1638968232626" MODIFIED="1638968232626" TEXT="assertNull()"/>
<node CREATED="1638968232628" MODIFIED="1638968232628" TEXT="assertArrayEquals()"/>
</node>
<node CREATED="1638968232629" MODIFIED="1638968232629" TEXT="Junit 4">
<node CREATED="1638968232631" ID="ID_53418133" MODIFIED="1638968232631" TEXT="@Before">
<node CREATED="1638968232632" MODIFIED="1638968232632" TEXT="runs before running every other test"/>
<node CREATED="1638968232634" MODIFIED="1638968232634" TEXT="helpful to initialize some data for db related tests"/>
</node>
<node CREATED="1638968232635" MODIFIED="1638968232635" TEXT="@After">
<node CREATED="1638968232636" MODIFIED="1638968232636" TEXT="runs after running every other test"/>
<node CREATED="1638968232638" MODIFIED="1638968232638" TEXT="helpful to perform cleanup"/>
</node>
<node CREATED="1638968232639" MODIFIED="1638968232639" TEXT="@BeforeClass">
<node CREATED="1638968232640" MODIFIED="1638968232640" TEXT="runs once per class at the start"/>
<node CREATED="1638968232641" MODIFIED="1638968232641" TEXT="helpful to establish db connection"/>
</node>
<node CREATED="1638968232642" MODIFIED="1638968232642" TEXT="@AfterClass">
<node CREATED="1638968232643" MODIFIED="1638968232643" TEXT="runs once per class at the end"/>
</node>
</node>
<node CREATED="1638968232645" HGAP="21" ID="ID_1633979791" MODIFIED="1638968276849" TEXT="JUnit 5" VSHIFT="49">
<node CREATED="1638968232646" MODIFIED="1638968232646" TEXT="@BeforeEach (instead of @Before)"/>
<node CREATED="1638968232648" MODIFIED="1638968232648" TEXT="@AfterEach (instead of @After)"/>
<node CREATED="1638968232649" MODIFIED="1638968232649" TEXT="@BeforeAll (instead of @BeforeClass)"/>
<node CREATED="1638968232650" MODIFIED="1638968232650" TEXT="@AfterAll (instead of @AfterClass)"/>
<node CREATED="1638968232651" MODIFIED="1638968232651" TEXT="@Disabled (instead of @Ignore)"/>
</node>
</node>
<node CREATED="1638968495157" HGAP="96" ID="ID_1020105994" MODIFIED="1639142153417" POSITION="right" TEXT="MVC" VSHIFT="-4">
<node CREATED="1638968495159" MODIFIED="1638968495159" TEXT="@Component">
<node CREATED="1638968495163" MODIFIED="1638968495163" TEXT="Generic"/>
</node>
<node CREATED="1638968495166" MODIFIED="1638968495166" TEXT="@Repository">
<node CREATED="1638968495168" MODIFIED="1638968495168" TEXT="DataBase"/>
</node>
<node CREATED="1638968495170" MODIFIED="1638968495170" TEXT="@Service">
<node CREATED="1638968495172" MODIFIED="1638968495172" TEXT="Business Service Facade"/>
</node>
<node CREATED="1638968495174" MODIFIED="1638968495174" TEXT="@Controller">
<node CREATED="1638968495176" MODIFIED="1638968495176" TEXT="Controller in MVC pattern"/>
</node>
</node>
<node CREATED="1639142025409" HGAP="129" ID="ID_66568500" MODIFIED="1639142142354" POSITION="right" TEXT="AOP" VSHIFT="-10">
<node CREATED="1639142025410" MODIFIED="1639142025410" TEXT="@Before">
<node CREATED="1639142025411" MODIFIED="1639142025411" TEXT="We need to provide the follwing details for the aspect class">
<node CREATED="1639142025412" LINK="mailto:(@Configuration)" MODIFIED="1639142025412" TEXT="Say to Spring that its configuration class (@Configuration)"/>
<node CREATED="1639142025414" LINK="mailto:(@Aspect)" MODIFIED="1639142025414" TEXT="Say it is AOP (@Aspect)"/>
<node CREATED="1639142025416" MODIFIED="1639142025416" TEXT="What kind of Intercept (before/after etc)">
<node CREATED="1639142025417" MODIFIED="1639142025417" TEXT="@Before(&quot;execution(* PACKAGE.*.*(..)&quot;)"/>
</node>
<node CREATED="1639142025419" MODIFIED="1639142025419" TEXT="Intercept Method implementation">
<node CREATED="1639142025420" MODIFIED="1639142025420" TEXT="Arguement for the intercept method (JointPoint jointPoint)">
<node CREATED="1639142025422" MODIFIED="1639142025422" TEXT="to get the method name that gets intercepted"/>
</node>
</node>
</node>
<node CREATED="1639142025423" MODIFIED="1639142025423" TEXT="Usually use @Before intercept to check for access (may be the user has right access)">
<node CREATED="1639142025425" MODIFIED="1639142025425" TEXT="And its done at one place for the entire application"/>
</node>
</node>
<node CREATED="1639142025426" MODIFIED="1639142025426" TEXT="@AfterReturning">
<node CREATED="1639142025427" MODIFIED="1639142025427" TEXT="After return from the actual method execution if we need to intercept to check the result"/>
<node CREATED="1639142025429" MODIFIED="1639142025429" TEXT="This will be intercepted only when the actual method&apos;s execution is successfully completed"/>
<node CREATED="1639142025431" MODIFIED="1639142025431" TEXT="@AfterReturning(value=&quot;execution(* PACKAGE.*.*(..)&quot;,returning=&quot;result&quot;)"/>
</node>
<node CREATED="1639142025432" MODIFIED="1639142025432" TEXT="@AfterThrowing">
<node CREATED="1639142025434" MODIFIED="1639142025434" TEXT="We can intercept, after an exception is thrown"/>
</node>
<node CREATED="1639142025435" MODIFIED="1639142025435" TEXT="@After">
<node CREATED="1639142025437" MODIFIED="1639142025437" TEXT="irrespective of if the intercepted method&apos;s execution is successful or exception thrown we can intercept using this"/>
</node>
<node CREATED="1639142025441" MODIFIED="1639142025441" TEXT="@Around">
<node CREATED="1639142025442" MODIFIED="1639142025442" TEXT="We intercept the actual method and then allow the actual method to execute"/>
<node CREATED="1639142025444" MODIFIED="1639142025444" TEXT="this would help in identifying the time a method takes to run. Helpful to determine the performance of a method"/>
<node CREATED="1639142025448" MODIFIED="1639142025448" TEXT="we use ProceedingJointPoint"/>
</node>
<node CREATED="1639142025449" MODIFIED="1639142025449" TEXT="@PointCut">
<node CREATED="1639142025451" MODIFIED="1639142025451" TEXT="Define all pointcuts (execution(...)) in a single place"/>
<node CREATED="1639142025452" MODIFIED="1639142025452" TEXT="Note: we still need to code the intercept method implementation at the different classes (that we had done above)"/>
</node>
</node>
</node>
</map>
