<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1640001244670" ID="ID_1702670218" MODIFIED="1640001408978" STYLE="bubble" TEXT="Spring MVC">
<node CREATED="1640001399001" MODIFIED="1640001408978" POSITION="right" TEXT="DispatcherServlet">
<node CREATED="1640001399002" MODIFIED="1640001408978" TEXT="Front Controller Pattern"/>
<node CREATED="1640001399004" MODIFIED="1640001408979" TEXT="All requests (web/mobile/anything) got to the DispatcherServlet"/>
<node CREATED="1640001399005" MODIFIED="1640001408979" TEXT="DispatcherServlet looks for the controller, try to find appropriate controller"/>
<node CREATED="1640001399006" MODIFIED="1640001408979" TEXT="Based on the reponse, it will either forward to another controller or display the response body"/>
</node>
<node CREATED="1640001399007" MODIFIED="1640001408979" POSITION="right" TEXT="@Controller">
<node CREATED="1640001399007" MODIFIED="1640001408979" TEXT="Tells spring that it is a controller"/>
<node CREATED="1640001399008" MODIFIED="1640001408979" TEXT="Controlled will handle Web Requests"/>
<node CREATED="1640001399009" MODIFIED="1640001408979" TEXT="Eg. LoginController (also known as Handler)"/>
</node>
<node CREATED="1640001399010" MODIFIED="1640001408979" POSITION="right" TEXT="@RequestMapping">
<node CREATED="1640001399011" MODIFIED="1640001408980" TEXT="Mapping an URL to the method"/>
</node>
<node CREATED="1640001399011" MODIFIED="1640001408980" POSITION="right" TEXT="@ResponsBody">
<node CREATED="1640001399012" MODIFIED="1640001408980" TEXT="Tells Spring that the response of the method is NOT the name URL"/>
<node CREATED="1640001399013" MODIFIED="1640001408980" TEXT="View"/>
<node CREATED="1640001399014" MODIFIED="1640001408980" TEXT="View is a JSP"/>
<node CREATED="1640001399015" MODIFIED="1640001408980" TEXT="The controller usually returns the view name (without .jsp extension Eg. login for login.jsp)"/>
<node CREATED="1640001399016" MODIFIED="1640001408980" TEXT="ViewResolver">
<node CREATED="1640001399016" MODIFIED="1640001408980" TEXT="Update the view resolver in spring servlet.xml (eg. todo-servlet.xml)"/>
<node CREATED="1640001399017" MODIFIED="1640001408981" TEXT="To tell the framework where would the jsp page be available"/>
<node CREATED="1640001399018" MODIFIED="1640001408981" TEXT="InternalResourceViewResolver">
<node CREATED="1640001399019" MODIFIED="1640001408981" TEXT="prefix - /WEB-INF/views/"/>
<node CREATED="1640001399019" MODIFIED="1640001408981" TEXT="suffix - .jsp"/>
<node CREATED="1640001399020" MODIFIED="1640001408981" TEXT="Controller (Login Controller) retun - jsp page name (eg. login)"/>
<node CREATED="1640001399021" MODIFIED="1640001408981" TEXT="Final View Resolved to">
<node CREATED="1640001399022" MODIFIED="1640001408981" TEXT="prefix+controller+suffix"/>
<node CREATED="1640001399022" MODIFIED="1640001408981" TEXT="/WEB-INF/views/login.jsp"/>
</node>
</node>
</node>
</node>
<node CREATED="1640001399023" MODIFIED="1640001408981" POSITION="right" TEXT="Model (ModelMap)">
<node CREATED="1640001399024" MODIFIED="1640001408982" TEXT="@RequestParam">
<node CREATED="1640001399025" MODIFIED="1640001408982" TEXT="To get the parameter passed from URL (or the form) to the controller)"/>
<node CREATED="1640001399026" MODIFIED="1640001408982" TEXT="The variable name should be same as the field name used in the form in JSP"/>
</node>
<node CREATED="1640001399027" MODIFIED="1640001408982" TEXT="Use Model to pass information between the Controller and the View">
<node CREATED="1640001399028" MODIFIED="1640001408982" TEXT="Add ModelMap as parameter to any method in the controller"/>
<node CREATED="1640001399029" MODIFIED="1640001408982" TEXT="Use model.put() to pass the information to View"/>
</node>
</node>
<node CREATED="1640001399029" MODIFIED="1640001408982" POSITION="right" TEXT="Log4j">
<node CREATED="1640001399030" MODIFIED="1640001408983" TEXT="/src/main/resources/log4j.properties">
<node CREATED="1640001399031" MODIFIED="1640001408983" TEXT="log4j.rootLogger=TRACE, Appender1, Appender2">
<node CREATED="1640001399032" MODIFIED="1640001408983" TEXT="Logger Levels-&gt; TRACE/DEBUG/INFO/WARN/ERROR (Trace gives highest details, Error the lowest)"/>
</node>
<node CREATED="1640001399033" MODIFIED="1640001408983" TEXT="log4j.appender.Appender1=org.apache.log4j.ConsoleAppender"/>
<node CREATED="1640001399033" MODIFIED="1640001408983" TEXT="log4j.appender.Appender1.layout=org.apache.log4j.PatternLayout"/>
<node CREATED="1640001399035" MODIFIED="1640001408983" TEXT="log4j.appender.Appender1.layout.ConversionPattern=%-7p %d [%t] %c %x - %m%n"/>
</node>
</node>
</node>
</map>
