<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1639142316417" ID="ID_1072601169" MODIFIED="1639837569647" STYLE="bubble" TEXT="Spring">
<node CREATED="1638766642982" FOLDED="true" HGAP="11" ID="ID_531106416" MODIFIED="1639838007624" POSITION="right" STYLE="bubble" TEXT="Spring Framework Needs" VSHIFT="-38">
<node CREATED="1638767727858" ID="ID_1741060278" LINK="mailto:(@Component)" MODIFIED="1638767822323" TEXT="What are beans (@Component)"/>
<node CREATED="1638767727864" ID="ID_755971799" LINK="mailto:(@Autowired)" MODIFIED="1638767763706" TEXT="What are dependencies (@Autowired)"/>
<node CREATED="1638767727865" ID="ID_1173655420" MODIFIED="1638767824524" TEXT="Where to Find Beans">
<node CREATED="1638767727867" HGAP="15" ID="ID_1618056144" MODIFIED="1638767845938" TEXT="@SpringBootApplication Class" VSHIFT="85">
<node CREATED="1638767727869" ID="ID_807012844" MODIFIED="1638767854253" TEXT="if bean class is same package as no need mention">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1638767727870" ID="ID_1421483780" MODIFIED="1638767763707" TEXT="This class contains ApplicationContext"/>
<node CREATED="1638767727874" ID="ID_1221135602" MODIFIED="1638767763707" TEXT="This Class have main() Method"/>
</node>
</node>
</node>
<node CREATED="1638767966065" FOLDED="true" HGAP="71" ID="ID_1292104122" MODIFIED="1639837995760" POSITION="left" STYLE="bubble" TEXT="Autowiring" VSHIFT="-41">
<node CREATED="1638768304731" HGAP="23" ID="ID_1474116272" MODIFIED="1638768350580" TEXT="ByType" VSHIFT="-36">
<node CREATED="1638768304732" ID="ID_359468528" MODIFIED="1638768315131" TEXT="By the Class/Interface Type"/>
<node CREATED="1638768304734" ID="ID_610689024" MODIFIED="1638768315131" TEXT="Or @Primary"/>
<node CREATED="1638768304737" ID="ID_490878550" MODIFIED="1638768315132" TEXT="@Primary takes higher precedence than ByName"/>
</node>
<node CREATED="1638768304738" HGAP="23" ID="ID_1056196475" MODIFIED="1638768348208" TEXT="ByName" VSHIFT="47">
<node CREATED="1638768304740" ID="ID_1312461688" MODIFIED="1638768315132" TEXT="By the Name of the Autowired Variables"/>
</node>
<node CREATED="1638768304742" FOLDED="true" HGAP="18" ID="ID_1391761501" MODIFIED="1639837489007" TEXT="@Qualifier" VSHIFT="65">
<node CREATED="1638768304743" ID="ID_919876582" MODIFIED="1638768315132" TEXT="Assign a qualifier name to each bean">
<node CREATED="1638768304744" HGAP="24" ID="ID_1538490840" MODIFIED="1638768361680" TEXT="Eg: @Qualifier(&quot;bubble&quot;) @Qualifier(&quot;sort&quot;)" VSHIFT="-19"/>
<node CREATED="1638768304747" HGAP="31" ID="ID_1008071363" MODIFIED="1638768366568" TEXT="Then Specify the qualifier name in the Implementation Class" VSHIFT="9"/>
</node>
</node>
</node>
<node CREATED="1638797663386" FOLDED="true" HGAP="58" ID="ID_142231789" MODIFIED="1639838004513" POSITION="right" STYLE="bubble" TEXT="Scope" VSHIFT="-29">
<node CREATED="1638797691207" MODIFIED="1638797702479" TEXT="singleton">
<node CREATED="1638797691210" MODIFIED="1638797702479" TEXT="Default"/>
<node CREATED="1638797691212" MODIFIED="1638797702480" TEXT="One Instace Per Spring Context"/>
<node CREATED="1638797691214" ID="ID_1597053951" MODIFIED="1638797715858" TEXT="If Bean is Singleton and the depenedency beans are Prototype">
<node CREATED="1638797691215" HGAP="13" ID="ID_715509297" MODIFIED="1638797721853" TEXT="On the dependency Class use Proxy to get new bean for the dependency" VSHIFT="60"/>
</node>
</node>
<node CREATED="1638797691217" MODIFIED="1638797702480" TEXT="prototype">
<node CREATED="1638797691219" MODIFIED="1638797702480" TEXT="new bean whenever requested"/>
<node CREATED="1638797691221" MODIFIED="1638797702480" TEXT="@Scope(&quot;prototype&quot;) in the implemenation class where we create object for the bean."/>
<node CREATED="1638797691223" MODIFIED="1638797702480" TEXT="@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE) - recommended Standard"/>
</node>
<node CREATED="1638797691225" MODIFIED="1638797702481" TEXT="request">
<node CREATED="1638797691226" MODIFIED="1638797702481" TEXT="one bean per HTTP request"/>
</node>
<node CREATED="1638797691227" MODIFIED="1638797702481" TEXT="session">
<node CREATED="1638797691229" MODIFIED="1638797702481" TEXT="one bean per HTTP session"/>
</node>
<node CREATED="1638797754480" ID="ID_1433954568" MODIFIED="1638797866852" TEXT="Singleton Scope Spring vs GOF">
<node CREATED="1638797759350" HGAP="18" ID="ID_1661849421" MODIFIED="1638797764249" TEXT="Spring Singleton" VSHIFT="-46">
<node CREATED="1638797759351" HGAP="14" ID="ID_507569445" MODIFIED="1638797793943" TEXT="One instance per SpringContext (Application Context)" VSHIFT="49"/>
</node>
<node CREATED="1638797759353" HGAP="15" ID="ID_755889044" MODIFIED="1638797766358" TEXT="GangOfFour(GOF - Design Pattern) Singleton" VSHIFT="25">
<node CREATED="1638797759354" HGAP="29" ID="ID_1497830047" MODIFIED="1638797802442" TEXT="One instance per JVM" VSHIFT="48"/>
</node>
</node>
</node>
<node CREATED="1638935338900" FOLDED="true" HGAP="73" ID="ID_1351460344" MODIFIED="1639837992486" POSITION="left" STYLE="bubble" TEXT="Life Cycle" VSHIFT="-34">
<node CREATED="1638935340336" ID="ID_223333552" MODIFIED="1638935573802" TEXT="@PostConstruct. This must be in the bean class (the implementation class)" VSHIFT="-39">
<node CREATED="1638935340339" HGAP="50" ID="ID_1694783408" MODIFIED="1638935562246" TEXT="If we need to perform certain actions ONLY after all dependecy beans are created then perform them in a methood with @PostConstruct annotation. " VSHIFT="-12"/>
<node CREATED="1638935340347" HGAP="61" ID="ID_1594727137" MODIFIED="1638935375989" TEXT="It must be Void type" VSHIFT="-3"/>
<node CREATED="1638935340349" HGAP="49" ID="ID_794398356" MODIFIED="1638935372121" TEXT="This will be called as soon as bean is created before any other method is called" VSHIFT="16"/>
</node>
<node CREATED="1638935340350" HGAP="35" ID="ID_1198439987" MODIFIED="1638935580399" TEXT="@PreDestroy This must be in the bean class (the implementation class)" VSHIFT="18">
<node CREATED="1638935340351" HGAP="45" ID="ID_1949586858" MODIFIED="1638935384007" TEXT="The last method to call just before the bean is destroyed" VSHIFT="1"/>
</node>
</node>
<node CREATED="1639043805058" FOLDED="true" HGAP="127" ID="ID_1547367550" MODIFIED="1639838009958" POSITION="right" STYLE="bubble" TEXT="AutoConfiguration" VSHIFT="-65">
<node CREATED="1639043811731" HGAP="8" ID="ID_1393926775" MODIFIED="1639043877310" TEXT="@SpringBootApplication" VSHIFT="-47">
<node CREATED="1639043811733" MODIFIED="1639043822088" TEXT="Indicates its a spring boot application"/>
<node CREATED="1639043811735" MODIFIED="1639043822088" TEXT="It Enables AutoConfiguration"/>
<node CREATED="1639043811736" MODIFIED="1639043822088" TEXT="It Enables Component Scan"/>
</node>
<node CREATED="1639043811738" HGAP="15" ID="ID_344501432" MODIFIED="1639043874565" TEXT="SpringBoot Looks at" VSHIFT="50">
<node CREATED="1639043811740" MODIFIED="1639043822089" TEXT="Frameworks Available on the CLASSPATH"/>
<node CREATED="1639043811742" ID="ID_901589696" MODIFIED="1639043822089" TEXT="Existing configurations for the application">
<node CREATED="1639043811744" ID="ID_27087755" MODIFIED="1639043897920" TEXT="Based on the above two, Spring boot provides the basic configuration needed for the application. This is called Auto Configuration"/>
</node>
</node>
</node>
<node CREATED="1639142213107" FOLDED="true" HGAP="22" ID="ID_1541891654" MODIFIED="1639838037000" POSITION="left" STYLE="bubble" TEXT="Aspect Oriented Programming (AOP)" VSHIFT="10">
<node CREATED="1639142223838" ID="ID_1373562637" MODIFIED="1639142223838" TEXT="Pointcut">
<node CREATED="1639142223839" ID="ID_1333093012" MODIFIED="1639142223839" TEXT="The expression which defines what kind of method we want to intercept is called pointcut"/>
<node CREATED="1639142223840" ID="ID_958083062" MODIFIED="1639142223840" TEXT="Format: execution(* PACKAGE.*.*(..)&quot;)">
<node CREATED="1639142223841" ID="ID_339894181" MODIFIED="1639142223841" TEXT="* -&gt; any return type"/>
<node CREATED="1639142223842" ID="ID_824529371" MODIFIED="1639142223842" TEXT="PACKAGE -&gt; full path of the package where the class/method to be intercepted resides"/>
<node CREATED="1639142223844" ID="ID_826788451" MODIFIED="1639142223844" TEXT="* -&gt; all classes inside the package"/>
<node CREATED="1639142223845" ID="ID_732308881" MODIFIED="1639142223845" TEXT="* -&gt; all methods of the class"/>
<node CREATED="1639142223846" ID="ID_696492615" MODIFIED="1639142223846" TEXT=".. -&gt; irrespective of number/type of arguements"/>
</node>
</node>
<node CREATED="1639142223847" ID="ID_104937835" MODIFIED="1639142223847" TEXT="Advice">
<node CREATED="1639142223847" ID="ID_1126708819" MODIFIED="1639142223847" TEXT="What should I do when I intercept a method"/>
</node>
<node CREATED="1639142223848" ID="ID_685509860" MODIFIED="1639142223848" TEXT="Aspect">
<node CREATED="1639142223851" ID="ID_1181195635" MODIFIED="1639142223851" TEXT="Combination of pointcut and advice is call Aspect"/>
</node>
<node CREATED="1639142223852" ID="ID_1206417788" MODIFIED="1639142223852" TEXT="JoinPoint">
<node CREATED="1639142223852" ID="ID_746703897" MODIFIED="1639142223852" TEXT="Specific interception of the method call."/>
<node CREATED="1639142223854" ID="ID_1961899569" MODIFIED="1639142223854" TEXT="Eg: if due to the pointcut (execution(...)) if there are 100 methods that got intercepeted, we would be having 100 jointpoints"/>
</node>
<node CREATED="1639142223857" ID="ID_1572444544" MODIFIED="1639142223857" TEXT="Weaving">
<node CREATED="1639142223858" ID="ID_1468949024" MODIFIED="1639142223858" TEXT="The process where this whole thing weaved around your code is called weaving"/>
</node>
<node CREATED="1639142223859" ID="ID_810444687" MODIFIED="1639142223859" TEXT="Weaver">
<node CREATED="1639142223860" ID="ID_335669012" MODIFIED="1639142223860" TEXT="The framwork which does the weaving is the Weaver"/>
</node>
<node CREATED="1639142223861" ID="ID_1361510924" MODIFIED="1639142223861" TEXT="Advice">
<node CREATED="1639142223862" ID="ID_272962653" MODIFIED="1639142223862" TEXT="@Before">
<node CREATED="1639142223863" ID="ID_1525474277" MODIFIED="1639142223863" TEXT="We need to provide the follwing details for the aspect class">
<node CREATED="1639142223864" ID="ID_399503541" LINK="mailto:(@Configuration)" MODIFIED="1639142223864" TEXT="Say to Spring that its configuration class (@Configuration)"/>
<node CREATED="1639142223866" ID="ID_1624700559" LINK="mailto:(@Aspect)" MODIFIED="1639142223866" TEXT="Say it is AOP (@Aspect)"/>
<node CREATED="1639142223867" ID="ID_1364080707" MODIFIED="1639142223867" TEXT="What kind of Intercept (before/after etc)">
<node CREATED="1639142223868" ID="ID_452324659" MODIFIED="1639142223868" TEXT="@Before(&quot;execution(* PACKAGE.*.*(..)&quot;)"/>
</node>
<node CREATED="1639142223869" ID="ID_1062431088" MODIFIED="1639142223869" TEXT="Intercept Method implementation">
<node CREATED="1639142223870" ID="ID_642167904" MODIFIED="1639142223870" TEXT="Arguement for the intercept method (JointPoint jointPoint)">
<node CREATED="1639142223871" ID="ID_228841476" MODIFIED="1639142223871" TEXT="to get the method name that gets intercepted"/>
</node>
</node>
</node>
<node CREATED="1639142223872" ID="ID_187323249" MODIFIED="1639142223872" TEXT="Usually use @Before intercept to check for access (may be the user has right access)">
<node CREATED="1639142223873" ID="ID_1031586441" MODIFIED="1639142223873" TEXT="And its done at one place for the entire application"/>
</node>
</node>
<node CREATED="1639142223874" ID="ID_695053967" MODIFIED="1639142223874" TEXT="@AfterReturning">
<node CREATED="1639142223875" ID="ID_12648690" MODIFIED="1639142223875" TEXT="After return from the actual method execution if we need to intercept to check the result"/>
<node CREATED="1639142223876" ID="ID_1834607277" MODIFIED="1639142223876" TEXT="This will be intercepted only when the actual method&apos;s execution is successfully completed"/>
<node CREATED="1639142223877" ID="ID_1263882807" MODIFIED="1639142223877" TEXT="@AfterReturning(value=&quot;execution(* PACKAGE.*.*(..)&quot;,returning=&quot;result&quot;)"/>
</node>
<node CREATED="1639142223878" ID="ID_989854302" MODIFIED="1639142223878" TEXT="@AfterThrowing">
<node CREATED="1639142223878" ID="ID_1948909843" MODIFIED="1639142223878" TEXT="We can intercept, after an exception is thrown"/>
</node>
<node CREATED="1639142223879" ID="ID_1954842747" MODIFIED="1639142223879" TEXT="@After">
<node CREATED="1639142223880" ID="ID_1832197083" MODIFIED="1639142223880" TEXT="irrespective of if the intercepted method&apos;s execution is successful or exception thrown we can intercept using this"/>
</node>
<node CREATED="1639142223882" ID="ID_151683241" MODIFIED="1639142223882" TEXT="@Around">
<node CREATED="1639142223884" ID="ID_1925691373" MODIFIED="1639142223884" TEXT="We intercept the actual method and then allow the actual method to execute"/>
<node CREATED="1639142223885" ID="ID_1401501168" MODIFIED="1639142223885" TEXT="this would help in identifying the time a method takes to run. Helpful to determine the performance of a method"/>
<node CREATED="1639142223886" ID="ID_1746851541" MODIFIED="1639142223886" TEXT="we use ProceedingJointPoint"/>
</node>
<node CREATED="1639142223887" ID="ID_574735552" MODIFIED="1639142223887" TEXT="@PointCut">
<node CREATED="1639142223888" ID="ID_1571482099" MODIFIED="1639142223888" TEXT="Define all pointcuts (execution(...)) in a single place"/>
<node CREATED="1639142223889" ID="ID_1660526538" MODIFIED="1639142223889" TEXT="Note: we still need to code the intercept method implementation at the different classes (that we had done above)"/>
</node>
</node>
</node>
<node CREATED="1639655608074" FOLDED="true" ID="ID_438775462" MODIFIED="1639838019507" POSITION="right" TEXT="Spring Database">
<node CREATED="1639655622657" FOLDED="true" HGAP="-3" ID="ID_1143133631" MODIFIED="1639838015404" STYLE="bubble" TEXT="Sprig JDBC" VSHIFT="-23">
<node CREATED="1639655629357" ID="ID_206479021" MODIFIED="1639838013960" TEXT="BeanPropertyRowMapper">
<node CREATED="1639655629359" MODIFIED="1639837569648" TEXT="Default Row Mapper Spring Provides"/>
<node CREATED="1639655629360" MODIFIED="1639837569648" TEXT="Maps the result set to the fields/attributes of a class (eg. Person.class)"/>
<node CREATED="1639655629361" MODIFIED="1639837569648" TEXT="Whenever we use this row mapper, the corresponding class for which the result set will be mapped (Person.class) should implement a no arguement constructor"/>
</node>
<node CREATED="1639655629363" MODIFIED="1639837569651" TEXT="JdbcTemplate">
<node CREATED="1639655629364" MODIFIED="1639837569651" TEXT="less number of lines of code"/>
<node CREATED="1639655629365" MODIFIED="1639837569651" TEXT="spring boot framework takes care of connection close &amp; exception handling"/>
<node CREATED="1639655629367" MODIFIED="1639837569651" TEXT="query">
<node CREATED="1639655629368" MODIFIED="1639837569651" TEXT="To query multiple the records"/>
</node>
<node CREATED="1639655629369" MODIFIED="1639837569651" TEXT="queryForObject">
<node CREATED="1639655629370" MODIFIED="1639837569651" TEXT="To query single record"/>
</node>
<node CREATED="1639655629371" MODIFIED="1639837569651" TEXT="update">
<node CREATED="1639655629372" MODIFIED="1639837569651" TEXT="can be used to insert, update or delete records"/>
</node>
</node>
<node CREATED="1639655629373" MODIFIED="1639837569652" TEXT="Custom JDBC Row Mapper">
<node CREATED="1639655629373" MODIFIED="1639837569652" TEXT="if the data that comes back from DB (result set) is of different structure compared to your bean/entity class (Person.class)">
<node CREATED="1639655629375" MODIFIED="1639837569653" TEXT="Eg. if the column name doesn&apos;t match the attribute name of the class"/>
</node>
</node>
</node>
<node CREATED="1639808947781" HGAP="29" ID="ID_176422239" MODIFIED="1639837569653" TEXT="JPA (Java Persistence API)" VSHIFT="-10">
<node CREATED="1639808947785" MODIFIED="1639837569653" TEXT="Writing a query directly inside the DAO may become more difficult to maintain as the system gets complex, the query to would get complex"/>
<node CREATED="1639808947788" MODIFIED="1639837569655" TEXT="JPA helps as manage it better"/>
<node CREATED="1639808947789" MODIFIED="1639837569656" TEXT="JPA is an interface &amp; Hibernate implements the JPA"/>
<node CREATED="1639808947790" MODIFIED="1639837569656" TEXT="@Entity"/>
<node CREATED="1639808947792" MODIFIED="1639837569656" TEXT="@Table(name=&quot;table name&quot;)"/>
<node CREATED="1639808947793" MODIFIED="1639837569656" TEXT="@Column(name=&quot;col name&quot;)"/>
<node CREATED="1639808947794" MODIFIED="1639837569656" TEXT="@Id">
<node CREATED="1639808947795" MODIFIED="1639837569656" TEXT="Define primary Key"/>
</node>
<node CREATED="1639808947797" MODIFIED="1639837569656" TEXT="@GeneratedValue">
<node CREATED="1639808947798" MODIFIED="1639837569657" TEXT="Generates value (incremental) based on the latest value in DB"/>
</node>
<node CREATED="1639808947799" MODIFIED="1639837569657" TEXT="@Transactional">
<node CREATED="1639808947800" MODIFIED="1639837569657" TEXT="Implement Transaction"/>
<node CREATED="1639808947801" MODIFIED="1639837569657" TEXT="At the Repository class (ideally at the Business Service Layer)"/>
</node>
<node CREATED="1639808947802" MODIFIED="1639837569657" TEXT="@PersistenceContext">
<node CREATED="1639808947803" MODIFIED="1639837569657" TEXT="EntityManager">
<node CREATED="1639808947804" MODIFIED="1639837569657" TEXT="Manages the Entities"/>
<node CREATED="1639808947805" MODIFIED="1639837569658" TEXT="All the operations that you perform in a specific session are stored in PersistenceContext"/>
<node CREATED="1639808947806" MODIFIED="1639837569658" TEXT="Entitiy Manager is the interface to PersistenceContext"/>
<node CREATED="1639808947807" MODIFIED="1639837569658" TEXT="find">
<node CREATED="1639808947808" MODIFIED="1639837569658" TEXT="to search by id/query parameter"/>
</node>
<node CREATED="1639808947809" MODIFIED="1639837569658" TEXT="merge">
<node CREATED="1639808947810" MODIFIED="1639837569658" TEXT="to update">
<node CREATED="1639808947810" MODIFIED="1639837569658" TEXT="if the id (primary key) in the (person) table is available it will update"/>
</node>
<node CREATED="1639808947811" MODIFIED="1639837569659" TEXT="to insert">
<node CREATED="1639808947812" MODIFIED="1639837569659" TEXT="if the id (primary key) in the (person) table is NOT available it will insert"/>
</node>
</node>
<node CREATED="1639808947813" MODIFIED="1639837569659" TEXT="remove">
<node CREATED="1639808947815" MODIFIED="1639837569659" TEXT="to delete">
<node CREATED="1639808947816" MODIFIED="1639837569660" TEXT="first findByID"/>
<node CREATED="1639808947818" MODIFIED="1639837569661" TEXT="pass the object we get from findById to delte"/>
</node>
</node>
<node CREATED="1639808947819" MODIFIED="1639837569661" TEXT="namedQuery.getResultSet()">
<node CREATED="1639808947820" MODIFIED="1639837569661" TEXT="JavaPersistenceQueryLanguage(JPQL)">
<node CREATED="1639808947821" MODIFIED="1639837569661" TEXT="createNamedQuery(&quot;&lt;name of the query&gt;&quot;)"/>
<node CREATED="1639808947823" MODIFIED="1639837569661" TEXT="@NamedQuery">
<node CREATED="1639808947824" MODIFIED="1639837569661" TEXT="Define the named query in the entity class"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1639810012416" HGAP="43" ID="ID_209074661" MODIFIED="1639837569661" TEXT="Spring Data JPA" VSHIFT="74">
<node CREATED="1639810012418" MODIFIED="1639837569662" TEXT="The logic to insert update find etc are exactly same whether it is for Person table or some other table"/>
<node CREATED="1639810012421" MODIFIED="1639837569662" TEXT="Spring Data further simpliefies it by pre defining in JPA Repository">
<node CREATED="1639810012424" MODIFIED="1639837569662" TEXT="create new interface (personSpringDataRepository)"/>
<node CREATED="1639810012426" MODIFIED="1639837569662" TEXT="And extend JpaRepository interface to the above"/>
<node CREATED="1639810012428" MODIFIED="1639837569662" TEXT="Create new Spring application class from the existing">
<node CREATED="1639810012430" MODIFIED="1639837569662" TEXT="Repalce update method call to save"/>
<node CREATED="1639810012432" MODIFIED="1639837569662" TEXT="here without the need to define the JPA repository class (like PersonJpaRepository / PersonJdbcDAO) we can perform basic CRUD operations"/>
</node>
</node>
<node CREATED="1639810012436" MODIFIED="1639837569666" TEXT="So with Spring Data we ONLY need to define your Entities and the JpaRepository Interface"/>
</node>
</node>
<node CREATED="1639837848975" FOLDED="true" HGAP="31" ID="ID_920602883" MODIFIED="1640001453734" POSITION="right" TEXT="Connecting to other DB" VSHIFT="76">
<node CREATED="1639837883828" ID="ID_1697718412" MODIFIED="1639837902658" TEXT="https://github.com/in28minutes/spring-master-class/tree/master/04-spring-jdbc-to-jpa"/>
</node>
<node CREATED="1640001244670" FOLDED="true" HGAP="43" ID="ID_1702670218" MODIFIED="1640001435541" POSITION="left" STYLE="bubble" TEXT="Spring MVC" VSHIFT="53">
<node CREATED="1640001399001" MODIFIED="1640001408978" TEXT="DispatcherServlet">
<node CREATED="1640001399002" MODIFIED="1640001408978" TEXT="Front Controller Pattern"/>
<node CREATED="1640001399004" MODIFIED="1640001408979" TEXT="All requests (web/mobile/anything) got to the DispatcherServlet"/>
<node CREATED="1640001399005" MODIFIED="1640001408979" TEXT="DispatcherServlet looks for the controller, try to find appropriate controller"/>
<node CREATED="1640001399006" MODIFIED="1640001408979" TEXT="Based on the reponse, it will either forward to another controller or display the response body"/>
</node>
<node CREATED="1640001399007" MODIFIED="1640001408979" TEXT="@Controller">
<node CREATED="1640001399007" MODIFIED="1640001408979" TEXT="Tells spring that it is a controller"/>
<node CREATED="1640001399008" MODIFIED="1640001408979" TEXT="Controlled will handle Web Requests"/>
<node CREATED="1640001399009" MODIFIED="1640001408979" TEXT="Eg. LoginController (also known as Handler)"/>
</node>
<node CREATED="1640001399010" MODIFIED="1640001408979" TEXT="@RequestMapping">
<node CREATED="1640001399011" MODIFIED="1640001408980" TEXT="Mapping an URL to the method"/>
</node>
<node CREATED="1640001399011" MODIFIED="1640001408980" TEXT="@ResponsBody">
<node CREATED="1640001399012" MODIFIED="1640001408980" TEXT="Tells Spring that the response of the method is NOT the name URL"/>
<node CREATED="1640001399013" MODIFIED="1640001408980" TEXT="View"/>
<node CREATED="1640001399014" MODIFIED="1640001408980" TEXT="View is a JSP"/>
<node CREATED="1640001399015" MODIFIED="1640001408980" TEXT="The controller usually returns the view name (without .jsp extension Eg. login for login.jsp)"/>
<node CREATED="1640001399016" MODIFIED="1640001408980" TEXT="ViewResolver">
<node CREATED="1640001399016" MODIFIED="1640001408980" TEXT="Update the view resolver in spring servlet.xml (eg. todo-servlet.xml)"/>
<node CREATED="1640001399017" MODIFIED="1640001408981" TEXT="To tell the framework where would the jsp page be available"/>
<node CREATED="1640001399018" MODIFIED="1640001408981" TEXT="InternalResourceViewResolver">
<node CREATED="1640001399019" MODIFIED="1640001408981" TEXT="prefix - /WEB-INF/views/"/>
<node CREATED="1640001399019" MODIFIED="1640001408981" TEXT="suffix - .jsp"/>
<node CREATED="1640001399020" MODIFIED="1640001408981" TEXT="Controller (Login Controller) retun - jsp page name (eg. login)"/>
<node CREATED="1640001399021" MODIFIED="1640001408981" TEXT="Final View Resolved to">
<node CREATED="1640001399022" MODIFIED="1640001408981" TEXT="prefix+controller+suffix"/>
<node CREATED="1640001399022" MODIFIED="1640001408981" TEXT="/WEB-INF/views/login.jsp"/>
</node>
</node>
</node>
</node>
<node CREATED="1640001399023" MODIFIED="1640001408981" TEXT="Model (ModelMap)">
<node CREATED="1640001399024" MODIFIED="1640001408982" TEXT="@RequestParam">
<node CREATED="1640001399025" MODIFIED="1640001408982" TEXT="To get the parameter passed from URL (or the form) to the controller)"/>
<node CREATED="1640001399026" MODIFIED="1640001408982" TEXT="The variable name should be same as the field name used in the form in JSP"/>
</node>
<node CREATED="1640001399027" MODIFIED="1640001408982" TEXT="Use Model to pass information between the Controller and the View">
<node CREATED="1640001399028" MODIFIED="1640001408982" TEXT="Add ModelMap as parameter to any method in the controller"/>
<node CREATED="1640001399029" MODIFIED="1640001408982" TEXT="Use model.put() to pass the information to View"/>
</node>
</node>
<node CREATED="1640001399029" MODIFIED="1640001408982" TEXT="Log4j">
<node CREATED="1640001399030" MODIFIED="1640001408983" TEXT="/src/main/resources/log4j.properties">
<node CREATED="1640001399031" MODIFIED="1640001408983" TEXT="log4j.rootLogger=TRACE, Appender1, Appender2">
<node CREATED="1640001399032" MODIFIED="1640001408983" TEXT="Logger Levels-&gt; TRACE/DEBUG/INFO/WARN/ERROR (Trace gives highest details, Error the lowest)"/>
</node>
<node CREATED="1640001399033" MODIFIED="1640001408983" TEXT="log4j.appender.Appender1=org.apache.log4j.ConsoleAppender"/>
<node CREATED="1640001399033" MODIFIED="1640001408983" TEXT="log4j.appender.Appender1.layout=org.apache.log4j.PatternLayout"/>
<node CREATED="1640001399035" MODIFIED="1640001408983" TEXT="log4j.appender.Appender1.layout.ConversionPattern=%-7p %d [%t] %c %x - %m%n"/>
</node>
</node>
</node>
</node>
</map>
