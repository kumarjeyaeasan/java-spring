<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1638797663386" ID="ID_142231789" MODIFIED="1639142346541" STYLE="bubble" TEXT="Scope">
<node CREATED="1638797691207" MODIFIED="1638797702479" POSITION="right" TEXT="singleton">
<node CREATED="1638797691210" MODIFIED="1638797702479" TEXT="Default"/>
<node CREATED="1638797691212" MODIFIED="1638797702480" TEXT="One Instace Per Spring Context"/>
<node CREATED="1638797691214" ID="ID_1597053951" MODIFIED="1638797715858" TEXT="If Bean is Singleton and the depenedency beans are Prototype">
<node CREATED="1638797691215" HGAP="13" ID="ID_715509297" MODIFIED="1638797721853" TEXT="On the dependency Class use Proxy to get new bean for the dependency" VSHIFT="60"/>
</node>
</node>
<node CREATED="1638797691217" MODIFIED="1638797702480" POSITION="right" TEXT="prototype">
<node CREATED="1638797691219" MODIFIED="1638797702480" TEXT="new bean whenever requested"/>
<node CREATED="1638797691221" MODIFIED="1638797702480" TEXT="@Scope(&quot;prototype&quot;) in the implemenation class where we create object for the bean."/>
<node CREATED="1638797691223" MODIFIED="1638797702480" TEXT="@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE) - recommended Standard"/>
</node>
<node CREATED="1638797691225" MODIFIED="1638797702481" POSITION="right" TEXT="request">
<node CREATED="1638797691226" MODIFIED="1638797702481" TEXT="one bean per HTTP request"/>
</node>
<node CREATED="1638797691227" MODIFIED="1638797702481" POSITION="right" TEXT="session">
<node CREATED="1638797691229" MODIFIED="1638797702481" TEXT="one bean per HTTP session"/>
</node>
<node CREATED="1638797754480" ID="ID_1433954568" MODIFIED="1638797866852" POSITION="left" TEXT="Singleton Scope Spring vs GOF">
<node CREATED="1638797759350" HGAP="18" ID="ID_1661849421" MODIFIED="1638797764249" TEXT="Spring Singleton" VSHIFT="-46">
<node CREATED="1638797759351" HGAP="14" ID="ID_507569445" MODIFIED="1638797793943" TEXT="One instance per SpringContext (Application Context)" VSHIFT="49"/>
</node>
<node CREATED="1638797759353" HGAP="15" ID="ID_755889044" MODIFIED="1638797766358" TEXT="GangOfFour(GOF - Design Pattern) Singleton" VSHIFT="25">
<node CREATED="1638797759354" HGAP="29" ID="ID_1497830047" MODIFIED="1638797802442" TEXT="One instance per JVM" VSHIFT="48"/>
</node>
</node>
</node>
</map>
