<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1639655608074" ID="ID_438775462" MODIFIED="1639837908892" STYLE="bubble" TEXT="Spring Database">
<node CREATED="1639655622657" FOLDED="true" HGAP="-3" ID="ID_1143133631" MODIFIED="1639837601804" POSITION="right" STYLE="bubble" TEXT="Sprig JDBC" VSHIFT="-23">
<node CREATED="1639655629357" MODIFIED="1639837595542" TEXT="BeanPropertyRowMapper">
<node CREATED="1639655629359" MODIFIED="1639837595542" TEXT="Default Row Mapper Spring Provides"/>
<node CREATED="1639655629360" MODIFIED="1639837595542" TEXT="Maps the result set to the fields/attributes of a class (eg. Person.class)"/>
<node CREATED="1639655629361" MODIFIED="1639837595542" TEXT="Whenever we use this row mapper, the corresponding class for which the result set will be mapped (Person.class) should implement a no arguement constructor"/>
</node>
<node CREATED="1639655629363" MODIFIED="1639837595543" TEXT="JdbcTemplate">
<node CREATED="1639655629364" MODIFIED="1639837595544" TEXT="less number of lines of code"/>
<node CREATED="1639655629365" MODIFIED="1639837595544" TEXT="spring boot framework takes care of connection close &amp; exception handling"/>
<node CREATED="1639655629367" MODIFIED="1639837595544" TEXT="query">
<node CREATED="1639655629368" MODIFIED="1639837595544" TEXT="To query multiple the records"/>
</node>
<node CREATED="1639655629369" MODIFIED="1639837595544" TEXT="queryForObject">
<node CREATED="1639655629370" MODIFIED="1639837595544" TEXT="To query single record"/>
</node>
<node CREATED="1639655629371" MODIFIED="1639837595544" TEXT="update">
<node CREATED="1639655629372" MODIFIED="1639837595544" TEXT="can be used to insert, update or delete records"/>
</node>
</node>
<node CREATED="1639655629373" MODIFIED="1639837595544" TEXT="Custom JDBC Row Mapper">
<node CREATED="1639655629373" MODIFIED="1639837595544" TEXT="if the data that comes back from DB (result set) is of different structure compared to your bean/entity class (Person.class)">
<node CREATED="1639655629375" MODIFIED="1639837595545" TEXT="Eg. if the column name doesn&apos;t match the attribute name of the class"/>
</node>
</node>
</node>
<node CREATED="1639808947781" FOLDED="true" HGAP="29" ID="ID_176422239" MODIFIED="1639837595545" POSITION="left" TEXT="JPA (Java Persistence API)" VSHIFT="-10">
<node CREATED="1639808947785" MODIFIED="1639808947785" TEXT="Writing a query directly inside the DAO may become more difficult to maintain as the system gets complex, the query to would get complex"/>
<node CREATED="1639808947788" MODIFIED="1639808947788" TEXT="JPA helps as manage it better"/>
<node CREATED="1639808947789" MODIFIED="1639808947789" TEXT="JPA is an interface &amp; Hibernate implements the JPA"/>
<node CREATED="1639808947790" MODIFIED="1639808947790" TEXT="@Entity"/>
<node CREATED="1639808947792" MODIFIED="1639808947792" TEXT="@Table(name=&quot;table name&quot;)"/>
<node CREATED="1639808947793" MODIFIED="1639808947793" TEXT="@Column(name=&quot;col name&quot;)"/>
<node CREATED="1639808947794" MODIFIED="1639808947794" TEXT="@Id">
<node CREATED="1639808947795" MODIFIED="1639808947795" TEXT="Define primary Key"/>
</node>
<node CREATED="1639808947797" MODIFIED="1639808947797" TEXT="@GeneratedValue">
<node CREATED="1639808947798" MODIFIED="1639808947798" TEXT="Generates value (incremental) based on the latest value in DB"/>
</node>
<node CREATED="1639808947799" MODIFIED="1639808947799" TEXT="@Transactional">
<node CREATED="1639808947800" MODIFIED="1639808947800" TEXT="Implement Transaction"/>
<node CREATED="1639808947801" MODIFIED="1639808947801" TEXT="At the Repository class (ideally at the Business Service Layer)"/>
</node>
<node CREATED="1639808947802" MODIFIED="1639808947802" TEXT="@PersistenceContext">
<node CREATED="1639808947803" MODIFIED="1639808947803" TEXT="EntityManager">
<node CREATED="1639808947804" MODIFIED="1639808947804" TEXT="Manages the Entities"/>
<node CREATED="1639808947805" MODIFIED="1639808947805" TEXT="All the operations that you perform in a specific session are stored in PersistenceContext"/>
<node CREATED="1639808947806" MODIFIED="1639808947806" TEXT="Entitiy Manager is the interface to PersistenceContext"/>
<node CREATED="1639808947807" MODIFIED="1639808947807" TEXT="find">
<node CREATED="1639808947808" MODIFIED="1639808947808" TEXT="to search by id/query parameter"/>
</node>
<node CREATED="1639808947809" MODIFIED="1639808947809" TEXT="merge">
<node CREATED="1639808947810" MODIFIED="1639808947810" TEXT="to update">
<node CREATED="1639808947810" MODIFIED="1639808947810" TEXT="if the id (primary key) in the (person) table is available it will update"/>
</node>
<node CREATED="1639808947811" MODIFIED="1639808947811" TEXT="to insert">
<node CREATED="1639808947812" MODIFIED="1639808947812" TEXT="if the id (primary key) in the (person) table is NOT available it will insert"/>
</node>
</node>
<node CREATED="1639808947813" MODIFIED="1639808947813" TEXT="remove">
<node CREATED="1639808947815" MODIFIED="1639808947815" TEXT="to delete">
<node CREATED="1639808947816" MODIFIED="1639808947816" TEXT="first findByID"/>
<node CREATED="1639808947818" MODIFIED="1639808947818" TEXT="pass the object we get from findById to delte"/>
</node>
</node>
<node CREATED="1639808947819" MODIFIED="1639808947819" TEXT="namedQuery.getResultSet()">
<node CREATED="1639808947820" MODIFIED="1639808947820" TEXT="JavaPersistenceQueryLanguage(JPQL)">
<node CREATED="1639808947821" MODIFIED="1639808947821" TEXT="createNamedQuery(&quot;&lt;name of the query&gt;&quot;)"/>
<node CREATED="1639808947823" MODIFIED="1639808947823" TEXT="@NamedQuery">
<node CREATED="1639808947824" MODIFIED="1639808947824" TEXT="Define the named query in the entity class"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1639810012416" FOLDED="true" HGAP="43" ID="ID_209074661" MODIFIED="1639837600072" POSITION="right" TEXT="Spring Data JPA" VSHIFT="74">
<node CREATED="1639810012418" MODIFIED="1639837595545" TEXT="The logic to insert update find etc are exactly same whether it is for Person table or some other table"/>
<node CREATED="1639810012421" MODIFIED="1639837595545" TEXT="Spring Data further simpliefies it by pre defining in JPA Repository">
<node CREATED="1639810012424" MODIFIED="1639837595545" TEXT="create new interface (personSpringDataRepository)"/>
<node CREATED="1639810012426" MODIFIED="1639837595546" TEXT="And extend JpaRepository interface to the above"/>
<node CREATED="1639810012428" MODIFIED="1639837595546" TEXT="Create new Spring application class from the existing">
<node CREATED="1639810012430" MODIFIED="1639837595546" TEXT="Repalce update method call to save"/>
<node CREATED="1639810012432" MODIFIED="1639837595546" TEXT="here without the need to define the JPA repository class (like PersonJpaRepository / PersonJdbcDAO) we can perform basic CRUD operations"/>
</node>
</node>
<node CREATED="1639810012436" MODIFIED="1639837595547" TEXT="So with Spring Data we ONLY need to define your Entities and the JpaRepository Interface"/>
</node>
<node CREATED="1639837848975" ID="ID_920602883" MODIFIED="1639837854102" POSITION="left" TEXT="Connecting to other DB">
<node CREATED="1639837883828" ID="ID_1697718412" MODIFIED="1639837902658" TEXT="https://github.com/in28minutes/spring-master-class/tree/master/04-spring-jdbc-to-jpa"/>
</node>
</node>
</map>
