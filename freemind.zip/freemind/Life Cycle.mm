<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1638935338900" ID="ID_1351460344" MODIFIED="1638935354064" STYLE="bubble" TEXT="Life Cycle">
<node CREATED="1638935340336" ID="ID_223333552" MODIFIED="1638935573802" POSITION="right" TEXT="@PostConstruct. This must be in the bean class (the implementation class)" VSHIFT="-39">
<node CREATED="1638935340339" HGAP="50" ID="ID_1694783408" MODIFIED="1638935562246" TEXT="If we need to perform certain actions ONLY after all dependecy beans are created then perform them in a methood with @PostConstruct annotation. " VSHIFT="-12"/>
<node CREATED="1638935340347" HGAP="61" ID="ID_1594727137" MODIFIED="1638935375989" TEXT="It must be Void type" VSHIFT="-3"/>
<node CREATED="1638935340349" HGAP="49" ID="ID_794398356" MODIFIED="1638935372121" TEXT="This will be called as soon as bean is created before any other method is called" VSHIFT="16"/>
</node>
<node CREATED="1638935340350" HGAP="35" ID="ID_1198439987" MODIFIED="1638935580399" POSITION="right" TEXT="@PreDestroy This must be in the bean class (the implementation class)" VSHIFT="18">
<node CREATED="1638935340351" HGAP="45" ID="ID_1949586858" MODIFIED="1638935384007" TEXT="The last method to call just before the bean is destroyed" VSHIFT="1"/>
</node>
</node>
</map>
