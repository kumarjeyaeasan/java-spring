<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1639142213107" ID="ID_1541891654" MODIFIED="1639837464251" TEXT="Aspect Oriented Programming (AOP)">
<node CREATED="1639142223838" ID="ID_1373562637" MODIFIED="1639142223838" POSITION="right" TEXT="Pointcut">
<node CREATED="1639142223839" ID="ID_1333093012" MODIFIED="1639142223839" TEXT="The expression which defines what kind of method we want to intercept is called pointcut"/>
<node CREATED="1639142223840" ID="ID_958083062" MODIFIED="1639142223840" TEXT="Format: execution(* PACKAGE.*.*(..)&quot;)">
<node CREATED="1639142223841" ID="ID_339894181" MODIFIED="1639142223841" TEXT="* -&gt; any return type"/>
<node CREATED="1639142223842" ID="ID_824529371" MODIFIED="1639142223842" TEXT="PACKAGE -&gt; full path of the package where the class/method to be intercepted resides"/>
<node CREATED="1639142223844" ID="ID_826788451" MODIFIED="1639142223844" TEXT="* -&gt; all classes inside the package"/>
<node CREATED="1639142223845" ID="ID_732308881" MODIFIED="1639142223845" TEXT="* -&gt; all methods of the class"/>
<node CREATED="1639142223846" ID="ID_696492615" MODIFIED="1639142223846" TEXT=".. -&gt; irrespective of number/type of arguements"/>
</node>
</node>
<node CREATED="1639142223847" ID="ID_104937835" MODIFIED="1639142223847" POSITION="right" TEXT="Advice">
<node CREATED="1639142223847" ID="ID_1126708819" MODIFIED="1639142223847" TEXT="What should I do when I intercept a method"/>
</node>
<node CREATED="1639142223848" ID="ID_685509860" MODIFIED="1639142223848" POSITION="right" TEXT="Aspect">
<node CREATED="1639142223851" ID="ID_1181195635" MODIFIED="1639142223851" TEXT="Combination of pointcut and advice is call Aspect"/>
</node>
<node CREATED="1639142223852" ID="ID_1206417788" MODIFIED="1639142223852" POSITION="right" TEXT="JoinPoint">
<node CREATED="1639142223852" ID="ID_746703897" MODIFIED="1639142223852" TEXT="Specific interception of the method call."/>
<node CREATED="1639142223854" ID="ID_1961899569" MODIFIED="1639142223854" TEXT="Eg: if due to the pointcut (execution(...)) if there are 100 methods that got intercepeted, we would be having 100 jointpoints"/>
</node>
<node CREATED="1639142223857" ID="ID_1572444544" MODIFIED="1639142223857" POSITION="right" TEXT="Weaving">
<node CREATED="1639142223858" ID="ID_1468949024" MODIFIED="1639142223858" TEXT="The process where this whole thing weaved around your code is called weaving"/>
</node>
<node CREATED="1639142223859" ID="ID_810444687" MODIFIED="1639142223859" POSITION="right" TEXT="Weaver">
<node CREATED="1639142223860" ID="ID_335669012" MODIFIED="1639142223860" TEXT="The framwork which does the weaving is the Weaver"/>
</node>
<node CREATED="1639142223861" ID="ID_1361510924" MODIFIED="1639142223861" POSITION="right" TEXT="Advice">
<node CREATED="1639142223862" ID="ID_272962653" MODIFIED="1639142223862" TEXT="@Before">
<node CREATED="1639142223863" ID="ID_1525474277" MODIFIED="1639142223863" TEXT="We need to provide the follwing details for the aspect class">
<node CREATED="1639142223864" ID="ID_399503541" LINK="mailto:(@Configuration)" MODIFIED="1639142223864" TEXT="Say to Spring that its configuration class (@Configuration)"/>
<node CREATED="1639142223866" ID="ID_1624700559" LINK="mailto:(@Aspect)" MODIFIED="1639142223866" TEXT="Say it is AOP (@Aspect)"/>
<node CREATED="1639142223867" ID="ID_1364080707" MODIFIED="1639142223867" TEXT="What kind of Intercept (before/after etc)">
<node CREATED="1639142223868" ID="ID_452324659" MODIFIED="1639142223868" TEXT="@Before(&quot;execution(* PACKAGE.*.*(..)&quot;)"/>
</node>
<node CREATED="1639142223869" ID="ID_1062431088" MODIFIED="1639142223869" TEXT="Intercept Method implementation">
<node CREATED="1639142223870" ID="ID_642167904" MODIFIED="1639142223870" TEXT="Arguement for the intercept method (JointPoint jointPoint)">
<node CREATED="1639142223871" ID="ID_228841476" MODIFIED="1639142223871" TEXT="to get the method name that gets intercepted"/>
</node>
</node>
</node>
<node CREATED="1639142223872" ID="ID_187323249" MODIFIED="1639142223872" TEXT="Usually use @Before intercept to check for access (may be the user has right access)">
<node CREATED="1639142223873" ID="ID_1031586441" MODIFIED="1639142223873" TEXT="And its done at one place for the entire application"/>
</node>
</node>
<node CREATED="1639142223874" ID="ID_695053967" MODIFIED="1639142223874" TEXT="@AfterReturning">
<node CREATED="1639142223875" ID="ID_12648690" MODIFIED="1639142223875" TEXT="After return from the actual method execution if we need to intercept to check the result"/>
<node CREATED="1639142223876" ID="ID_1834607277" MODIFIED="1639142223876" TEXT="This will be intercepted only when the actual method&apos;s execution is successfully completed"/>
<node CREATED="1639142223877" ID="ID_1263882807" MODIFIED="1639142223877" TEXT="@AfterReturning(value=&quot;execution(* PACKAGE.*.*(..)&quot;,returning=&quot;result&quot;)"/>
</node>
<node CREATED="1639142223878" ID="ID_989854302" MODIFIED="1639142223878" TEXT="@AfterThrowing">
<node CREATED="1639142223878" ID="ID_1948909843" MODIFIED="1639142223878" TEXT="We can intercept, after an exception is thrown"/>
</node>
<node CREATED="1639142223879" ID="ID_1954842747" MODIFIED="1639142223879" TEXT="@After">
<node CREATED="1639142223880" ID="ID_1832197083" MODIFIED="1639142223880" TEXT="irrespective of if the intercepted method&apos;s execution is successful or exception thrown we can intercept using this"/>
</node>
<node CREATED="1639142223882" ID="ID_151683241" MODIFIED="1639142223882" TEXT="@Around">
<node CREATED="1639142223884" ID="ID_1925691373" MODIFIED="1639142223884" TEXT="We intercept the actual method and then allow the actual method to execute"/>
<node CREATED="1639142223885" ID="ID_1401501168" MODIFIED="1639142223885" TEXT="this would help in identifying the time a method takes to run. Helpful to determine the performance of a method"/>
<node CREATED="1639142223886" ID="ID_1746851541" MODIFIED="1639142223886" TEXT="we use ProceedingJointPoint"/>
</node>
<node CREATED="1639142223887" ID="ID_574735552" MODIFIED="1639142223887" TEXT="@PointCut">
<node CREATED="1639142223888" ID="ID_1571482099" MODIFIED="1639142223888" TEXT="Define all pointcuts (execution(...)) in a single place"/>
<node CREATED="1639142223889" ID="ID_1660526538" MODIFIED="1639142223889" TEXT="Note: we still need to code the intercept method implementation at the different classes (that we had done above)"/>
</node>
</node>
</node>
</map>
