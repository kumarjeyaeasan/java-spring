<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1638767966065" ID="ID_1292104122" MODIFIED="1638768331687" STYLE="bubble" TEXT="Autowiring">
<node CREATED="1638768304731" HGAP="23" ID="ID_1474116272" MODIFIED="1638768350580" POSITION="right" TEXT="ByType" VSHIFT="-36">
<node CREATED="1638768304732" MODIFIED="1638768315131" TEXT="By the Class/Interface Type"/>
<node CREATED="1638768304734" MODIFIED="1638768315131" TEXT="Or @Primary"/>
<node CREATED="1638768304737" MODIFIED="1638768315132" TEXT="@Primary takes higher precedence than ByName"/>
</node>
<node CREATED="1638768304738" HGAP="23" ID="ID_1056196475" MODIFIED="1638768348208" POSITION="right" TEXT="ByName" VSHIFT="47">
<node CREATED="1638768304740" MODIFIED="1638768315132" TEXT="By the Name of the Autowired Variables"/>
</node>
<node CREATED="1638768304742" HGAP="18" ID="ID_1391761501" MODIFIED="1638768344859" POSITION="right" TEXT="@Qualifier" VSHIFT="65">
<node CREATED="1638768304743" MODIFIED="1638768315132" TEXT="Assign a qualifier name to each bean">
<node CREATED="1638768304744" HGAP="24" ID="ID_1538490840" MODIFIED="1638768361680" TEXT="Eg: @Qualifier(&quot;bubble&quot;) @Qualifier(&quot;sort&quot;)" VSHIFT="-19"/>
<node CREATED="1638768304747" HGAP="31" ID="ID_1008071363" MODIFIED="1638768366568" TEXT="Then Specify the qualifier name in the Implementation Class" VSHIFT="9"/>
</node>
</node>
</node>
</map>
