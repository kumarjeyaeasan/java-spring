<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1638797754480" ID="ID_1433954568" MODIFIED="1638797866852" TEXT="Singleton Scope Spring vs GOF">
<node CREATED="1638797759350" HGAP="18" ID="ID_1661849421" MODIFIED="1638797764249" POSITION="right" TEXT="Spring Singleton" VSHIFT="-46">
<node CREATED="1638797759351" HGAP="14" ID="ID_507569445" MODIFIED="1638797793943" TEXT="One instance per SpringContext (Application Context)" VSHIFT="49"/>
</node>
<node CREATED="1638797759353" HGAP="15" ID="ID_755889044" MODIFIED="1638797766358" POSITION="right" TEXT="GangOfFour(GOF - Design Pattern) Singleton" VSHIFT="25">
<node CREATED="1638797759354" HGAP="29" ID="ID_1497830047" MODIFIED="1638797802442" TEXT="One instance per JVM" VSHIFT="48"/>
</node>
</node>
</map>
